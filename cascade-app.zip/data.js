/**
 * CASCADE — Question Bank & Educational Content
 * JEE Main 2026 Indefinite Integration
 * Each step features exactly 4 multiple-choice options with realistic JEE distractors.
 */

const CASCADE_QUESTIONS = [
  {
    id: "JEE26-M-01",
    index: 1,
    title: "JEE Main 2026 (23 January Shift 1)",
    subject: "Mathematics",
    topic: "Indefinite Integration",
    subtopic: "Exponential & Radical Forms",
    difficulty: "Hard",
    year: "2026",
    tags: ["JEE Main", "Integration by Parts", "e^x Form", "Calculus"],
    statement: "Let \\( f(x) = \\int \\frac{(2-x^2) e^x}{\\sqrt{1+x}\\,(1-x)^{3/2}}\\, dx \\). If \\( f(0) = 0 \\), then \\( f\\left(\\frac{1}{2}\\right) \\) is equal to:",
    options: [
      { id: 1, text: "\\( \\sqrt{3e} - 1 \\)", isCorrect: true },
      { id: 2, text: "\\( \\sqrt{3e} + 1 \\)", isCorrect: false },
      { id: 3, text: "\\( \\sqrt{2e} + 1 \\)", isCorrect: false },
      { id: 4, text: "\\( \\sqrt{2e} - 1 \\)", isCorrect: false }
    ],
    correctOptionId: 1,
    directExplanation: {
      overview: "This problem leverages the classic exponential differential form \\( \\int e^x [g(x) + g'(x)] dx = e^x g(x) + C \\). The crux lies in decomposing the polynomial numerator \\( 2-x^2 \\) to create cancellation with the radical denominator.",
      steps: [
        {
          heading: "Step 1: Algebraic Partition of the Numerator",
          detail: "Observe that \\( 2 - x^2 = 1 + (1 - x^2) = 1 + (1-x)(1+x) \\). This splits the integrand into two separate fractions."
        },
        {
          heading: "Step 2: Splitting and Simplifying the Fractions",
          detail: "\\frac{(2-x^2)e^x}{\\sqrt{1+x}(1-x)^{3/2}} = e^x \\left[ \\frac{(1-x)(1+x)}{\\sqrt{1+x}(1-x)^{3/2}} + \\frac{1}{\\sqrt{1+x}(1-x)^{3/2}} \\right] = e^x \\left[ \\sqrt{\\frac{1+x}{1-x}} + \\frac{1}{\\sqrt{1+x}(1-x)^{3/2}} \\right]"
        },
        {
          heading: "Step 3: Verification of the Derivative Pair",
          detail: "\\text{Let } g(x) = \\sqrt{\\frac{1+x}{1-x}}. \\quad g'(x) = \\frac{1}{2\\sqrt{\\frac{1+x}{1-x}}} \\cdot \\frac{(1-x)(1) - (1+x)(-1)}{(1-x)^2} = \\frac{1}{\\sqrt{1+x}(1-x)^{3/2}}."
        },
        {
          heading: "Step 4: Evaluating the Antiderivative & Constant",
          detail: "f(x) = e^x g(x) + C = e^x \\sqrt{\\frac{1+x}{1-x}} + C.\\\\[4pt] \\text{Given } f(0) = 0 \\implies e^0 \\sqrt{1} + C = 0 \\implies 1 + C = 0 \\implies C = -1.\\\\[4pt] f(x) = e^x \\sqrt{\\frac{1+x}{1-x}} - 1."
        },
        {
          heading: "Step 5: Final Substitution at x = 1/2",
          detail: "f(1/2) = e^{1/2} \\sqrt{\\frac{1 + 1/2}{1 - 1/2}} - 1 = \\sqrt{e}\\sqrt{\\frac{3/2}{1/2}} - 1 = \\sqrt{3e} - 1."
        }
      ],
      theorems: [
        "\\int e^x [g(x) + g'(x)] dx = e^x g(x) + C",
        "\\frac{d}{dx}\\left(\\sqrt{\\frac{1+x}{1-x}}\\right) = \\frac{1}{\\sqrt{1+x}(1-x)^{3/2}}"
      ],
      pitfall: "Common error: Many students mistakenly think the constant \\( C = 0 \\) because \\( f(0)=0 \\), forgetting that \\( e^0 \\sqrt{1} = 1 \\)."
    },
    stepwiseHints: [
      {
        stepIndex: 1,
        title: "Step 1: Partitioning the Numerator",
        instruction: "Notice the \\( e^x \\) multiplier and denominator \\( \\sqrt{1+x}(1-x)^{3/2} \\). To create manageable terms, split \\( 2 - x^2 \\) using \\( (1-x^2) \\).",
        options: [
          { id: 'A', text: "\\( 2 - x^2 = (1-x)(1+x) + 1 \\)", isCorrect: true, feedback: "Correct! Writing \\( 2-x^2 = (1-x^2) + 1 = (1-x)(1+x) + 1 \\) allows exact cancellation with the denominator terms." },
          { id: 'B', text: "\\( 2 - x^2 = 2(1-x)^2 - x \\)", isCorrect: false, feedback: "Incorrect. Expanding gives \\( 2(1 - 2x + x^2) - x = 2 - 5x + 2x^2 \\neq 2 - x^2 \\)." },
          { id: 'C', text: "\\( 2 - x^2 = (2-x)(1+x) \\)", isCorrect: false, feedback: "Incorrect. Expanding gives \\( 2 + x - x^2 \\neq 2 - x^2 \\)." },
          { id: 'D', text: "\\( 2 - x^2 = (1+x)^2 - 2x - 1 \\)", isCorrect: false, feedback: "Incorrect. That simplifies to \\( x^2 \\), which fails to match \\( 2-x^2 \\)." }
        ],
        takeaway: "Decomposing \\( 2-x^2 \\) as \\( (1-x)(1+x) + 1 \\) splits the integrand into two distinct fractions."
      },
      {
        stepIndex: 2,
        title: "Step 2: Identifying the Target Function g(x)",
        instruction: "After dividing each term by \\( \\sqrt{1+x}(1-x)^{3/2} \\), the first term simplifies to \\( \\sqrt{\\frac{1+x}{1-x}} \\). Check its derivative.",
        options: [
          { id: 'A', text: "\\( g(x) = \\sqrt{\\frac{1+x}{1-x}} \\implies g'(x) = \\frac{1}{\\sqrt{1+x}(1-x)^{3/2}} \\)", isCorrect: true, feedback: "Spot on! The derivative matches the second fraction term exactly, confirming the \\( e^x [g(x) + g'(x)] \\) format." },
          { id: 'B', text: "\\( g(x) = \\sqrt{1-x^2} \\implies g'(x) = -\\frac{x}{\\sqrt{1-x^2}} \\)", isCorrect: false, feedback: "Incorrect. The simplified first term has denominator \\( \\sqrt{1-x} \\) and numerator \\( \\sqrt{1+x} \\), not \\( \\sqrt{1-x^2} \\)." },
          { id: 'C', text: "\\( g(x) = \\frac{1}{1-x} \\implies g'(x) = \\frac{1}{(1-x)^2} \\)", isCorrect: false, feedback: "Incorrect. This does not account for the radical \\( \\sqrt{1+x} \\) factor." },
          { id: 'D', text: "\\( g(x) = \\sqrt{\\frac{1-x}{1+x}} \\implies g'(x) = -\\frac{1}{\\sqrt{1-x}(1+x)^{3/2}} \\)", isCorrect: false, feedback: "Incorrect. The inverted fraction gives a negative derivative which does not match our second positive term." }
        ],
        takeaway: "The function \\( g(x) = \\sqrt{\\frac{1+x}{1-x}} \\) satisfies the identity \\( \\int e^x [g(x) + g'(x)] dx = e^x g(x) + C \\)."
      },
      {
        stepIndex: 3,
        title: "Step 3: Finding the Constant of Integration C",
        instruction: "Use the initial condition \\( f(0) = 0 \\) on \\( f(x) = e^x \\sqrt{\\frac{1+x}{1-x}} + C \\).",
        options: [
          { id: 'A', text: "\\( C = -1 \\)", isCorrect: true, feedback: "Correct! \\( f(0) = e^0 \\sqrt{\\frac{1}{1}} + C = 1 + C = 0 \\implies C = -1 \\)." },
          { id: 'B', text: "\\( C = 0 \\)", isCorrect: false, feedback: "Incorrect. Remember that \\( e^0 = 1 \\) and \\( \\sqrt{1/1} = 1 \\), so the constant term is non-zero." },
          { id: 'C', text: "\\( C = 1 \\)", isCorrect: false, feedback: "Incorrect. If \\( C = 1 \\), then \\( f(0) = 1 + 1 = 2 \\neq 0 \\)." },
          { id: 'D', text: "\\( C = -\\sqrt{3} \\)", isCorrect: false, feedback: "Incorrect. There is no radical factor remaining when evaluating at \\( x = 0 \\)." }
        ],
        takeaway: "The complete function is \\( f(x) = e^x \\sqrt{\\frac{1+x}{1-x}} - 1 \\)."
      },
      {
        stepIndex: 4,
        title: "Step 4: Evaluating f(1/2)",
        instruction: "Substitute \\( x = 1/2 \\) into \\( f(x) = e^x \\sqrt{\\frac{1+x}{1-x}} - 1 \\).",
        options: [
          { id: 'A', text: "\\( f(1/2) = \\sqrt{3e} - 1 \\)", isCorrect: true, feedback: "Bravo! \\( e^{1/2}\\sqrt{\\frac{3/2}{1/2}} - 1 = \\sqrt{e}\\cdot\\sqrt{3} - 1 = \\sqrt{3e} - 1 \\)." },
          { id: 'B', text: "\\( f(1/2) = \\sqrt{3e} + 1 \\)", isCorrect: false, feedback: "Incorrect. Recall \\( C = -1 \\), so it must be subtracted." },
          { id: 'C', text: "\\( f(1/2) = \\sqrt{2e} - 1 \\)", isCorrect: false, feedback: "Incorrect. \\( \\frac{1 + 1/2}{1 - 1/2} = \\frac{1.5}{0.5} = 3 \\), not 2." },
          { id: 'D', text: "\\( f(1/2) = 3\\sqrt{e} - 1 \\)", isCorrect: false, feedback: "Incorrect. The 3 is inside the radical: \\( \\sqrt{3} \\), not 3." }
        ],
        takeaway: "Final Answer: Option 1 (\\( \\sqrt{3e} - 1 \\))."
      }
    ]
  },
  {
    id: "JEE26-M-02",
    index: 2,
    title: "JEE Main 2026 (28 January Shift 2)",
    subject: "Mathematics",
    topic: "Indefinite Integration",
    subtopic: "Fractional Exponent Substitution",
    difficulty: "Hard",
    year: "2026",
    tags: ["JEE Main", "Rationalizing Substitution", "Polynomial Division", "Logarithms"],
    statement: "Let \\( f(x) = \\int \\frac{dx}{x^{2/3} + 2x^{1/2}} \\) be such that \\( f(0) = -26 + 24 \\log_e(2) \\). If \\( f(1) = a + b \\log_e(3) \\), where \\( a, b \\in \\mathbb{Z} \\), then \\( a + b \\) is equal to:",
    options: [
      { id: 1, text: "\\( -26 \\)", isCorrect: false },
      { id: 2, text: "\\( -11 \\)", isCorrect: true },
      { id: 3, text: "\\( -5 \\)", isCorrect: false },
      { id: 4, text: "\\( -18 \\)", isCorrect: false }
    ],
    correctOptionId: 2,
    directExplanation: {
      overview: "When dealing with fractional exponents with denominators 3 and 2, the standard strategy is setting \\( x = u^{\\text{LCM}(3,2)} = u^6 \\). This transforms the algebraic integrand into a clean rational function in \\( u \\).",
      steps: [
        {
          heading: "Step 1: Rationalizing Substitution",
          detail: "\\text{LCM}(3,2) = 6 \\implies \\text{Substitute } x = u^6 \\implies dx = 6u^5 du.\\\\ x^{2/3} = u^4, \\quad x^{1/2} = u^3."
        },
        {
          heading: "Step 2: Algebraic Simplification",
          detail: "\\int \\frac{6u^5 du}{u^4 + 2u^3} = \\int \\frac{6u^5 du}{u^3(u + 2)} = \\int \\frac{6u^2 du}{u + 2}."
        },
        {
          heading: "Step 3: Polynomial Division & Integration",
          detail: "\\frac{u^2}{u+2} = u - 2 + \\frac{4}{u+2}.\\\\[4pt] f(x) = 6 \\int \\left( u - 2 + \\frac{4}{u+2} \\right) du = 6\\left(\\frac{u^2}{2} - 2u + 4\\ln(u+2)\\right) + C\\\\ = 3u^2 - 12u + 24\\ln(u+2) + C = 3x^{1/3} - 12x^{1/6} + 24\\ln(x^{1/6}+2) + C."
        },
        {
          heading: "Step 4: Boundary Condition at x = 0",
          detail: "f(0) = 0 - 0 + 24\\ln(2) + C = -26 + 24\\ln(2) \\implies C = -26."
        },
        {
          heading: "Step 5: Value at x = 1 and sum a + b",
          detail: "f(1) = 3(1) - 12(1) + 24\\ln(3) - 26 = -35 + 24\\ln(3).\\\\[4pt] a = -35, \\; b = 24 \\implies a + b = -35 + 24 = -11."
        }
      ],
      theorems: [
        "x = u^{\\text{LCM}(q_1, q_2)} \\text{ clears fractional indices}",
        "\\frac{u^2}{u+2} = u - 2 + \\frac{4}{u+2}"
      ],
      pitfall: "Forgetting the differential factor \\( dx = 6u^5 du \\) when substituting leads to completely wrong powers."
    },
    stepwiseHints: [
      {
        stepIndex: 1,
        title: "Step 1: Choosing the Rationalizing Substitution",
        instruction: "The denominators of the powers are 3 (from 2/3) and 2 (from 1/2). What substitution eliminates both fractions?",
        options: [
          { id: 'A', text: "\\( x = u^6 \\implies dx = 6u^5 du \\)", isCorrect: true, feedback: "Correct! \\( \\text{LCM}(3,2) = 6 \\), so \\( x^{2/3} = u^4 \\) and \\( x^{1/2} = u^3 \\), making all exponents integers." },
          { id: 'B', text: "\\( x = u^3 \\implies dx = 3u^2 du \\)", isCorrect: false, feedback: "Incorrect. \\( (u^3)^{1/2} = u^{3/2} \\), which leaves a fractional power." },
          { id: 'C', text: "\\( x = u^2 \\implies dx = 2u du \\)", isCorrect: false, feedback: "Incorrect. \\( (u^2)^{2/3} = u^{4/3} \\), which also leaves a fractional exponent." },
          { id: 'D', text: "\\( x = u^{12} \\implies dx = 12u^{11} du \\)", isCorrect: false, feedback: "Incorrect. While 12 clears fractions, it creates unnecessary high-degree algebra." }
        ],
        takeaway: "Using \\( x = u^6 \\) converts the integral to \\( \\int \\frac{6u^5 du}{u^4 + 2u^3} \\)."
      },
      {
        stepIndex: 2,
        title: "Step 2: Division and Simplification",
        instruction: "Factor out \\( u^3 \\) in the denominator and divide \\( u^2 \\) by \\( (u+2) \\).",
        options: [
          { id: 'A', text: "\\( \\frac{6u^2}{u+2} = 6\\left( u - 2 + \\frac{4}{u+2} \\right) \\)", isCorrect: true, feedback: "Correct! \\( u^2 = (u^2 - 4) + 4 = (u-2)(u+2) + 4 \\), so dividing by \\( (u+2) \\) yields \\( u - 2 + 4/(u+2) \\)." },
          { id: 'B', text: "\\( \\frac{6u^2}{u+2} = 6\\left( u + 2 - \\frac{4}{u+2} \\right) \\)", isCorrect: false, feedback: "Incorrect. Multiplying back gives \\( u^2 - 4 - 4 \\neq u^2 \\)." },
          { id: 'C', text: "\\( \\frac{6u^2}{u+2} = 6u - 12 \\)", isCorrect: false, feedback: "Incorrect. You cannot discard the remainder term \\( 4/(u+2) \\)." },
          { id: 'D', text: "\\( \\frac{6u^2}{u+2} = 6\\left( u - 1 + \\frac{2}{u+2} \\right) \\)", isCorrect: false, feedback: "Incorrect. Check the polynomial long division remainder." }
        ],
        takeaway: "The integral integrates directly to \\( 3u^2 - 12u + 24\\ln(u+2) + C \\)."
      },
      {
        stepIndex: 3,
        title: "Step 3: Determining Constant C",
        instruction: "Recall \\( u = x^{1/6} \\). Use the boundary value \\( f(0) = -26 + 24\\ln(2) \\).",
        options: [
          { id: 'A', text: "\\( C = -26 \\)", isCorrect: true, feedback: "Correct! At \\( x = 0 \\implies u = 0 \\), \\( f(0) = 24\\ln(2) + C = -26 + 24\\ln(2) \\implies C = -26 \\)." },
          { id: 'B', text: "\\( C = 24 \\)", isCorrect: false, feedback: "Incorrect. Notice that \\( 24\\ln(2) \\) appears on both sides and cancels out." },
          { id: 'C', text: "\\( C = 0 \\)", isCorrect: false, feedback: "Incorrect. The constant term \\( -26 \\) must be matched by \\( C \\)." },
          { id: 'D', text: "\\( C = -12 \\)", isCorrect: false, feedback: "Incorrect. \\( -12u \\) evaluates to 0 when \\( u = 0 \\)." }
        ],
        takeaway: "The complete antiderivative is \\( f(x) = 3x^{1/3} - 12x^{1/6} + 24\\ln(x^{1/6}+2) - 26 \\)."
      },
      {
        stepIndex: 4,
        title: "Step 4: Computing a, b, and their sum a + b",
        instruction: "Evaluate \\( f(1) \\) and compare with \\( a + b\\ln(3) \\).",
        options: [
          { id: 'A', text: "\\( a = -35, \\; b = 24 \\implies a + b = -11 \\)", isCorrect: true, feedback: "Bingo! \\( f(1) = 3(1) - 12(1) + 24\\ln(3) - 26 = -35 + 24\\ln(3) \\). Hence \\( -35 + 24 = -11 \\)." },
          { id: 'B', text: "\\( a = -26, \\; b = 24 \\implies a + b = -2 \\)", isCorrect: false, feedback: "Incorrect. You missed the \\( 3 - 12 = -9 \\) algebraic contribution." },
          { id: 'C', text: "\\( a = -35, \\; b = 3 \\implies a + b = -32 \\)", isCorrect: false, feedback: "Incorrect. The coefficient of the log term is 24, not 3." },
          { id: 'D', text: "\\( a = -11, \\; b = 24 \\implies a + b = 13 \\)", isCorrect: false, feedback: "Incorrect. \\( a \\) is \\( -35 \\); \\( -11 \\) is the sum." }
        ],
        takeaway: "Final Answer: Option 2 (\\( -11 \\))."
      }
    ]
  },
  {
    id: "JEE26-M-03",
    index: 3,
    title: "JEE Main 2026 (22 January Shift 1)",
    subject: "Mathematics",
    topic: "Indefinite Integration",
    subtopic: "Negative Even Exponents in Trig",
    difficulty: "Hard",
    year: "2026",
    tags: ["JEE Main", "Trigonometric Substitution", "Cotangent Identity", "Coprime Ratio"],
    statement: "If \\( \\int (\\sin x)^{-11/2} (\\cos x)^{-5/2} dx = -\\frac{p_1}{q_1}(\\cot x)^{9/2} - \\frac{p_2}{q_2}(\\cot x)^{5/2} - \\frac{p_3}{q_3}(\\cot x)^{1/2} + \\frac{p_4}{q_4}(\\cot x)^{-3/2} + C \\), where \\( p_i, q_i \\) are positive integers with \\( \\gcd(p_i, q_i) = 1 \\), then \\( \\frac{15 p_1 p_2 p_3 p_4}{q_1 q_2 q_3 q_4} \\) is equal to:",
    options: [
      { id: 1, text: "\\( 12 \\)", isCorrect: false },
      { id: 2, text: "\\( 16 \\)", isCorrect: true },
      { id: 3, text: "\\( 24 \\)", isCorrect: false },
      { id: 4, text: "\\( 30 \\)", isCorrect: false }
    ],
    correctOptionId: 2,
    directExplanation: {
      overview: "For integrals \\( \\int \\sin^m x \\cos^n x dx \\), when \\( m+n \\) is a negative even integer, we convert to \\( \\cot x \\) or \\( \\tan x \\). Since the target format is in powers of \\( \\cot x \\), substitute \\( t = \\cot x \\).",
      steps: [
        {
          heading: "Step 1: Check the Exponent Condition",
          detail: "m = -11/2, \\; n = -5/2 \\implies m + n = -16/2 = -8 \\quad (\\text{negative even integer!})"
        },
        {
          heading: "Step 2: Substitution t = cot(x)",
          detail: "t = \\cot x \\implies dt = -\\csc^2 x dx \\implies dx = -\\frac{dt}{1+t^2}.\\\\[4pt] \\text{Also } \\sin x = \\frac{1}{\\sqrt{1+t^2}}."
        },
        {
          heading: "Step 3: Transforming to Algebraic Polynomial",
          detail: "\\int \\frac{(\\cot x)^{-5/2}}{\\sin^8 x} dx = -\\int t^{-5/2} (1+t^2)^3 dt = -\\int (t^{-5/2} + 3t^{-1/2} + 3t^{3/2} + t^{7/2}) dt."
        },
        {
          heading: "Step 4: Term-by-Term Integration",
          detail: "= -\\left[ -\\frac{2}{3}t^{-3/2} + 6t^{1/2} + \\frac{6}{5}t^{5/2} + \\frac{2}{9}t^{9/2} \\right] + C\\\\ = -\\frac{2}{9}t^{9/2} - \\frac{6}{5}t^{5/2} - \\frac{6}{1}t^{1/2} + \\frac{2}{3}t^{-3/2} + C."
        },
        {
          heading: "Step 5: Evaluating the Value",
          detail: "\\frac{p_1}{q_1} = \\frac{2}{9}, \\; \\frac{p_2}{q_2} = \\frac{6}{5}, \\; \\frac{p_3}{q_3} = \\frac{6}{1}, \\; \\frac{p_4}{q_4} = \\frac{2}{3}.\\\\[4pt] \\frac{15 p_1 p_2 p_3 p_4}{q_1 q_2 q_3 q_4} = 15 \\cdot \\frac{2 \\cdot 6 \\cdot 6 \\cdot 2}{9 \\cdot 5 \\cdot 1 \\cdot 3} = 15 \\cdot \\frac{144}{135} = 16."
        }
      ],
      theorems: [
        "m+n = -2k \\implies \\text{substitute } t = \\cot x",
        "(1+t^2)^3 = 1 + 3t^2 + 3t^4 + t^6"
      ],
      pitfall: "Take care when matching negative signs in front of each term in the question prompt."
    },
    stepwiseHints: [
      {
        stepIndex: 1,
        title: "Step 1: Identifying the Transformation Condition",
        instruction: "Inspect the powers of sine and cosine: \\( m = -11/2 \\) and \\( n = -5/2 \\). What identity governs this form?",
        options: [
          { id: 'A', text: "\\( m + n = -8 \\) (negative even integer), so substitute \\( t = \\cot x \\)", isCorrect: true, feedback: "Correct! When \\( m+n \\) is a negative even integer, expressing in \\( \\cot x \\) and \\( \\csc x \\) generates a pure polynomial in \\( t \\)." },
          { id: 'B', text: "\\( m - n = -3 \\) (odd integer), so use integration by parts", isCorrect: false, feedback: "Incorrect. The sum of powers is the governing condition here, not the difference." },
          { id: 'C', text: "Use substitution \\( t = \\sin x \\cos x \\)", isCorrect: false, feedback: "Incorrect. This does not rationalize fractional fractional exponents." },
          { id: 'D', text: "Multiply and divide by \\( \\sec^2 x \\)", isCorrect: false, feedback: "Incorrect. The target form is specifically in powers of \\( \\cot x \\)." }
        ],
        takeaway: "Substitute \\( t = \\cot x \\) with \\( dx = -\\frac{dt}{1+t^2} \\)."
      },
      {
        stepIndex: 2,
        title: "Step 2: Binomial Expansion in Terms of t",
        instruction: "Expand \\( (1+t^2)^3 \\) and multiply by \\( t^{-5/2} \\). What is the resulting integrand?",
        options: [
          { id: 'A', text: "\\( -\\int (t^{-5/2} + 3t^{-1/2} + 3t^{3/2} + t^{7/2}) dt \\)", isCorrect: true, feedback: "Spot on! Using \\( (1+y)^3 = 1 + 3y + 3y^2 + y^3 \\) with \\( y = t^2 \\) gives powers \\( -5/2, -1/2, 3/2, 7/2 \\)." },
          { id: 'B', text: "\\( -\\int (t^{-5/2} + 2t^{-1/2} + t^{3/2}) dt \\)", isCorrect: false, feedback: "Incorrect. You used coefficients for a square \\( (1+t^2)^2 \\) rather than a cube." },
          { id: 'C', text: "\\( \\int (t^{-5/2} - 3t^{-1/2} + 3t^{3/2} - t^{7/2}) dt \\)", isCorrect: false, feedback: "Incorrect. The term is \\( (1+t^2)^3 \\), so all expansion signs are positive." },
          { id: 'D', text: "\\( -\\int (t^{-3/2} + 3t^{1/2} + 3t^{5/2} + t^{9/2}) dt \\)", isCorrect: false, feedback: "Incorrect. Exponent arithmetic: \\( -5/2 + 0 = -5/2 \\), not \\( -3/2 \\)." }
        ],
        takeaway: "Integrand simplifies to \\( -\\int (t^{-5/2} + 3t^{-1/2} + 3t^{3/2} + t^{7/2}) dt \\)."
      },
      {
        stepIndex: 3,
        title: "Step 3: Integrating and Extracting Ratios p_i / q_i",
        instruction: "Integrate each power of \\( t \\) and compare with the given expression.",
        options: [
          { id: 'A', text: "\\( \\frac{p_1}{q_1} = \\frac{2}{9},\\; \\frac{p_2}{q_2} = \\frac{6}{5},\\; \\frac{p_3}{q_3} = \\frac{6}{1},\\; \\frac{p_4}{q_4} = \\frac{2}{3} \\)", isCorrect: true, feedback: "Correct! \\( \\int t^{7/2} dt = \\frac{2}{9}t^{9/2} \\), \\( 3\\int t^{3/2} dt = \\frac{6}{5}t^{5/2} \\), etc." },
          { id: 'B', text: "\\( \\frac{p_1}{q_1} = \\frac{1}{9},\\; \\frac{p_2}{q_2} = \\frac{3}{5},\\; \\frac{p_3}{q_3} = 3,\\; \\frac{p_4}{q_4} = \\frac{1}{3} \\)", isCorrect: false, feedback: "Incorrect. The fraction denominator 2 inverts to multiply the coefficient by 2." },
          { id: 'C', text: "\\( \\frac{p_1}{q_1} = \\frac{2}{3},\\; \\frac{p_2}{q_2} = 6,\\; \\frac{p_3}{q_3} = \\frac{6}{5},\\; \\frac{p_4}{q_4} = \\frac{2}{9} \\)", isCorrect: false, feedback: "Incorrect. The order of fractions is reversed." },
          { id: 'D', text: "\\( \\frac{p_1}{q_1} = \\frac{4}{9},\\; \\frac{p_2}{q_2} = \\frac{12}{5},\\; \\frac{p_3}{q_3} = 12,\\; \\frac{p_4}{q_4} = \\frac{4}{3} \\)", isCorrect: false, feedback: "Incorrect. Unnecessary doubling of coefficients." }
        ],
        takeaway: "The coefficients are \\( 2/9, 6/5, 6/1, 2/3 \\)."
      },
      {
        stepIndex: 4,
        title: "Step 4: Evaluating the Target Product",
        instruction: "Compute \\( \\frac{15 \\cdot p_1 \\cdot p_2 \\cdot p_3 \\cdot p_4}{q_1 \\cdot q_2 \\cdot q_3 \\cdot q_4} \\).",
        options: [
          { id: 'A', text: "\\( 16 \\)", isCorrect: true, feedback: "Bingo! \\( 15 \\times \\frac{2 \\times 6 \\times 6 \\times 2}{9 \\times 5 \\times 1 \\times 3} = 15 \\times \\frac{144}{135} = \\frac{2160}{135} = 16 \\)." },
          { id: 'B', text: "\\( 12 \\)", isCorrect: false, feedback: "Incorrect. Check your cancellation of 15 with \\( 5 \\times 3 = 15 \\)." },
          { id: 'C', text: "\\( 24 \\)", isCorrect: false, feedback: "Incorrect. Recompute \\( 144 / 9 = 16 \\)." },
          { id: 'D', text: "\\( 30 \\)", isCorrect: false, feedback: "Incorrect. Check the factors." }
        ],
        takeaway: "Final Answer: Option 2 (16)."
      }
    ]
  },
  {
    id: "JEE26-M-04",
    index: 4,
    title: "JEE Main 2026 (23 January Shift 2)",
    subject: "Mathematics",
    topic: "Indefinite Integration",
    subtopic: "Linear-Quadratic Radical Integration",
    difficulty: "Hard",
    year: "2026",
    tags: ["JEE Main", "Secant Substitution", "Factoring", "Evaluation"],
    statement: "Let \\( I(x) = \\int \\frac{3dx}{(4x+6)\\sqrt{4x^2+8x+3}} \\) and \\( I(0) = \\frac{\\sqrt{3}}{4} + 20 \\). If \\( I\\left(\\frac{1}{2}\\right) = \\frac{a\\sqrt{2}}{b} + c \\), where \\( a, b, c \\in \\mathbb{N},\\; \\gcd(a, b) = 1 \\), then \\( a + b + c \\) is equal to:",
    options: [
      { id: 1, text: "\\( 30 \\)", isCorrect: false },
      { id: 2, text: "\\( 31 \\)", isCorrect: true },
      { id: 3, text: "\\( 29 \\)", isCorrect: false },
      { id: 4, text: "\\( 28 \\)", isCorrect: false }
    ],
    correctOptionId: 2,
    directExplanation: {
      overview: "Factoring reveals a shared linear factor \\( (2x+3) \\) between the denominator and the quadratic radical. A linear substitution \\( u = 2x+3 \\) followed by trigonometric substitution solves this cleanly.",
      steps: [
        {
          heading: "Step 1: Factoring the Expressions",
          detail: "4x+6 = 2(2x+3)\\\\[4pt] 4x^2 + 8x + 3 = (2x+3)(2x+1)."
        },
        {
          heading: "Step 2: Linear Substitution u = 2x + 3",
          detail: "u = 2x+3 \\implies 2x+1 = u-2, \\quad dx = du/2.\\\\[4pt] I(x) = \\int \\frac{3(du/2)}{2u \\sqrt{u(u-2)}} = \\frac{3}{4} \\int \\frac{du}{u^{3/2}\\sqrt{u-2}}."
        },
        {
          heading: "Step 3: Trig Substitution u = 2 sec^2(phi)",
          detail: "u = 2\\sec^2 \\phi \\implies u-2 = 2\\tan^2 \\phi, \\; du = 4\\sec^2 \\phi \\tan \\phi d\\phi.\\\\[4pt] I = \\frac{3}{4} \\int \\cos \\phi d\\phi = \\frac{3}{4}\\sin \\phi + C = \\frac{3}{4}\\sqrt{\\frac{2x+1}{2x+3}} + C."
        },
        {
          heading: "Step 4: Finding Constant C",
          detail: "I(0) = \\frac{3}{4}\\sqrt{\\frac{1}{3}} + C = \\frac{\\sqrt{3}}{4} + C = \\frac{\\sqrt{3}}{4} + 20 \\implies C = 20."
        },
        {
          heading: "Step 5: Evaluating at x = 1/2",
          detail: "I(1/2) = \\frac{3}{4}\\sqrt{\\frac{2}{4}} + 20 = \\frac{3\\sqrt{2}}{8} + 20.\\\\[4pt] a = 3, \\; b = 8, \\; c = 20 \\implies a + b + c = 3 + 8 + 20 = 31."
        }
      ],
      theorems: [
        "4x^2+8x+3 = (2x+3)(2x+1)",
        "\\int \\frac{du}{u^{3/2}\\sqrt{u-2}} = \\sin \\phi + C = \\sqrt{\\frac{u-2}{u}} + C"
      ],
      pitfall: "Missing the factor 2 in \\( 4x+6 = 2(2x+3) \\) and \\( dx = du/2 \\) throws off the constant coefficient \\( 3/4 \\)."
    },
    stepwiseHints: [
      {
        stepIndex: 1,
        title: "Step 1: Factoring the Quadratic Under the Radical",
        instruction: "Inspect \\( 4x^2 + 8x + 3 \\) and \\( 4x + 6 \\). How can both be written in terms of a shared linear binomial?",
        options: [
          { id: 'A', text: "\\( 4x+6 = 2(2x+3) \\) and \\( 4x^2+8x+3 = (2x+3)(2x+1) \\)", isCorrect: true, feedback: "Correct! The shared linear term is \\( 2x+3 \\), which suggests setting \\( u = 2x+3 \\)." },
          { id: 'B', text: "\\( 4x+6 = 2(2x+3) \\) and \\( 4x^2+8x+3 = (4x+3)(x+1) \\)", isCorrect: false, feedback: "Incorrect. \\( (4x+3)(x+1) = 4x^2 + 7x + 3 \\neq 4x^2 + 8x + 3 \\)." },
          { id: 'C', text: "\\( 4x+6 = 4(x+1.5) \\) and \\( 4x^2+8x+3 = (2x-3)(2x-1) \\)", isCorrect: false, feedback: "Incorrect. Signs in the quadratic factors must be positive." },
          { id: 'D', text: "\\( 4x+6 = 2(2x+3) \\) and \\( 4x^2+8x+3 = (2x+3)^2 - 6 \\)", isCorrect: false, feedback: "Incorrect. Expanding \\( (2x+3)^2 - 6 = 4x^2 + 12x + 3 \\neq 4x^2 + 8x + 3 \\)." }
        ],
        takeaway: "Both expressions share the factor \\( 2x+3 \\)."
      },
      {
        stepIndex: 2,
        title: "Step 2: Linear Substitution u = 2x + 3",
        instruction: "Substitute \\( u = 2x+3 \\). Note \\( 2x+1 = u-2 \\) and \\( dx = du/2 \\). What is the transformed integral?",
        options: [
          { id: 'A', text: "\\( \\frac{3}{4} \\int \\frac{du}{u^{3/2}\\sqrt{u-2}} \\)", isCorrect: true, feedback: "Spot on! The factor \\( 2 \\) from \\( 4x+6 \\) and \\( 2 \\) from \\( dx = du/2 \\) give \\( 1/4 \\), leaving \\( \\frac{3}{4} \\frac{du}{u \\cdot u^{1/2} \\sqrt{u-2}} \\)." },
          { id: 'B', text: "\\( \\frac{3}{2} \\int \\frac{du}{u\\sqrt{u-2}} \\)", isCorrect: false, feedback: "Incorrect. The term \\( u \\) multiplies with \\( \\sqrt{u} \\) giving \\( u^{3/2} \\)." },
          { id: 'C', text: "\\( 3 \\int \\frac{du}{u^2\\sqrt{u-2}} \\)", isCorrect: false, feedback: "Incorrect. You missed the factor 4 in the denominator." },
          { id: 'D', text: "\\( \\frac{3}{4} \\int \\frac{du}{u\\sqrt{u-1}} \\)", isCorrect: false, feedback: "Incorrect. \\( 2x+1 = (2x+3) - 2 = u - 2 \\), not \\( u-1 \\)." }
        ],
        takeaway: "The integral is \\( \\frac{3}{4} \\int \\frac{du}{u^{3/2}\\sqrt{u-2}} \\)."
      },
      {
        stepIndex: 3,
        title: "Step 3: Determining Antiderivative Form and Constant",
        instruction: "Integrating via \\( u = 2\\sec^2 \\phi \\) gives \\( I(x) = \\frac{3}{4}\\sqrt{\\frac{2x+1}{2x+3}} + C \\). Use \\( I(0) = \\frac{\\sqrt{3}}{4} + 20 \\) to find \\( C \\).",
        options: [
          { id: 'A', text: "\\( C = 20 \\)", isCorrect: true, feedback: "Correct! \\( I(0) = \\frac{3}{4}\\frac{1}{\\sqrt{3}} + C = \\frac{\\sqrt{3}}{4} + C = \\frac{\\sqrt{3}}{4} + 20 \\implies C = 20 \\)." },
          { id: 'B', text: "\\( C = \\frac{\\sqrt{3}}{4} \\)", isCorrect: false, feedback: "Incorrect. Notice that \\( \\frac{\\sqrt{3}}{4} \\) is the value of the function term itself at 0." },
          { id: 'C', text: "\\( C = 0 \\)", isCorrect: false, feedback: "Incorrect. The constant term 20 must be accounted for." },
          { id: 'D', text: "\\( C = 20 + \\frac{\\sqrt{3}}{4} \\)", isCorrect: false, feedback: "Incorrect. The square root cancels out on both sides." }
        ],
        takeaway: "The complete function is \\( I(x) = \\frac{3}{4}\\sqrt{\\frac{2x+1}{2x+3}} + 20 \\)."
      },
      {
        stepIndex: 4,
        title: "Step 4: Evaluating at x = 1/2 and Finding a + b + c",
        instruction: "Calculate \\( I(1/2) \\) in the form \\( \\frac{a\\sqrt{2}}{b} + c \\) with \\( \\gcd(a,b) = 1 \\).",
        options: [
          { id: 'A', text: "\\( a = 3, \\; b = 8, \\; c = 20 \\implies a + b + c = 31 \\)", isCorrect: true, feedback: "Bravo! \\( I(1/2) = \\frac{3}{4}\\sqrt{\\frac{2}{4}} + 20 = \\frac{3}{4\\sqrt{2}} + 20 = \\frac{3\\sqrt{2}}{8} + 20 \\). Sum is \\( 3 + 8 + 20 = 31 \\)." },
          { id: 'B', text: "\\( a = 3, \\; b = 4, \\; c = 20 \\implies a + b + c = 27 \\)", isCorrect: false, feedback: "Incorrect. Rationalizing \\( \\frac{3}{4\\sqrt{2}} \\) gives \\( \\frac{3\\sqrt{2}}{8} \\), so \\( b = 8 \\), not 4." },
          { id: 'C', text: "\\( a = 6, \\; b = 16, \\; c = 20 \\implies a + b + c = 42 \\)", isCorrect: false, feedback: "Incorrect. The problem requires coprime integers \\( \\gcd(a,b) = 1 \\)." },
          { id: 'D', text: "\\( a = 1, \\; b = 2, \\; c = 20 \\implies a + b + c = 23 \\)", isCorrect: false, feedback: "Incorrect. The coefficient 3 remains in the numerator." }
        ],
        takeaway: "Final Answer: Option 2 (31)."
      }
    ]
  },
  {
    id: "JEE26-M-05",
    index: 5,
    title: "JEE Main 2026 (24 January Shift 1)",
    subject: "Mathematics",
    topic: "Indefinite Integration",
    subtopic: "Log-Trig Half-Angle Form",
    difficulty: "Hard",
    year: "2026",
    tags: ["JEE Main", "Half-Angle Trig", "Log Substitution", "cot(pi/8)"],
    statement: "Let \\( f(t) = \\int \\left( \\frac{1 - \\sin(\\log_e t)}{1 - \\cos(\\log_e t)} \\right) dt, \\quad t > 1 \\). If \\( f(e^{\\pi/2}) = -e^{\\pi/2} \\) and \\( f(e^{\\pi/4}) = \\alpha e^{\\pi/4} \\), then \\( \\alpha \\) equals:",
    options: [
      { id: 1, text: "\\( 1 + \\sqrt{2} \\)", isCorrect: false },
      { id: 2, text: "\\( -1 - \\sqrt{2} \\)", isCorrect: true },
      { id: 3, text: "\\( -1 - 2\\sqrt{2} \\)", isCorrect: false },
      { id: 4, text: "\\( -1 + \\sqrt{2} \\)", isCorrect: false }
    ],
    correctOptionId: 2,
    directExplanation: {
      overview: "Substituting \\( u = \\log_e t \\implies t = e^u, \\; dt = e^u du \\) converts this into \\( \\int e^u [g(u) + g'(u)] du \\). Half-angle trigonometric identities reveal the exact function pair.",
      steps: [
        {
          heading: "Step 1: Logarithmic Substitution",
          detail: "u = \\log_e t \\implies t = e^u, \\; dt = e^u du.\\\\[4pt] f(t) = \\int e^u \\left(\\frac{1-\\sin u}{1-\\cos u}\\right) du."
        },
        {
          heading: "Step 2: Half-Angle Trig Decomposition",
          detail: "1 - \\cos u = 2\\sin^2(u/2), \\quad \\sin u = 2\\sin(u/2)\\cos(u/2).\\\\[4pt] \\frac{1-\\sin u}{1-\\cos u} = \\frac{1}{2}\\csc^2(u/2) - \\cot(u/2)."
        },
        {
          heading: "Step 3: Recognition of g(u) + g'(u)",
          detail: "\\text{Let } g(u) = -\\cot(u/2). \\quad g'(u) = \\frac{1}{2}\\csc^2(u/2).\\\\[4pt] \\int e^u \\left[-\\cot(u/2) + \\frac{1}{2}\\csc^2(u/2)\\right] du = -e^u \\cot(u/2) + C = -t \\cot\\left(\\frac{\\log_e t}{2}\\right) + C."
        },
        {
          heading: "Step 4: Finding Constant C",
          detail: "f(e^{\\pi/2}) = -e^{\\pi/2}\\cot(\\pi/4) + C = -e^{\\pi/2}(1) + C.\\\\[4pt] \\text{Given } f(e^{\\pi/2}) = -e^{\\pi/2} \\implies -e^{\\pi/2} + C = -e^{\\pi/2} \\implies C = 0."
        },
        {
          heading: "Step 5: Evaluating alpha at t = e^(pi/4)",
          detail: "f(e^{\\pi/4}) = -e^{\\pi/4}\\cot(\\pi/8).\\\\[4pt] \\text{Using } \\cot(\\pi/8) = \\sqrt{2} + 1:\\\\ f(e^{\\pi/4}) = -(\\sqrt{2}+1)e^{\\pi/4} = (-1-\\sqrt{2})e^{\\pi/4} = \\alpha e^{\\pi/4} \\implies \\alpha = -1 - \\sqrt{2}."
        }
      ],
      theorems: [
        "1 - \\cos u = 2\\sin^2(u/2)",
        "\\frac{d}{du}\\left(-\\cot\\frac{u}{2}\\right) = \\frac{1}{2}\\csc^2\\frac{u}{2}",
        "\\cot\\left(\\frac{\\pi}{8}\\right) = 1 + \\sqrt{2}"
      ],
      pitfall: "Mind the negative sign: \\( \\frac{d}{du}\\cot(u/2) = -\\frac{1}{2}\\csc^2(u/2) \\), so to get \\( +\\frac{1}{2}\\csc^2(u/2) \\), the function must be \\( -\\cot(u/2) \\)."
    },
    stepwiseHints: [
      {
        stepIndex: 1,
        title: "Step 1: Transforming via Logarithmic Substitution",
        instruction: "Notice the argument \\( \\log_e t \\). Let \\( u = \\log_e t \\). What is \\( dt \\) and the new integral?",
        options: [
          { id: 'A', text: "\\( dt = e^u du \\implies \\int e^u \\left( \\frac{1-\\sin u}{1-\\cos u} \\right) du \\)", isCorrect: true, feedback: "Correct! \\( t = e^u \\implies dt = e^u du \\), introducing the crucial exponential multiplier." },
          { id: 'B', text: "\\( dt = du \\implies \\int \\left( \\frac{1-\\sin u}{1-\\cos u} \\right) du \\)", isCorrect: false, feedback: "Incorrect. \\( dt/du = e^u \\), so \\( dt \\neq du \\)." },
          { id: 'C', text: "\\( dt = \\frac{1}{u} du \\implies \\int \\frac{1}{u}\\left( \\frac{1-\\sin u}{1-\\cos u} \\right) du \\)", isCorrect: false, feedback: "Incorrect. That would be the derivative of \\( \\ln t \\), not \\( dt \\)." },
          { id: 'D', text: "\\( dt = e^{-u} du \\implies \\int e^{-u}\\left( \\frac{1-\\sin u}{1-\\cos u} \\right) du \\)", isCorrect: false, feedback: "Incorrect. \\( t = e^u \\), so \\( dt = +e^u du \\)." }
        ],
        takeaway: "The integral converts to the exponential format \\( \\int e^u \\left(\\frac{1-\\sin u}{1-\\cos u}\\right) du \\)."
      },
      {
        stepIndex: 2,
        title: "Step 2: Half-Angle Trigonometric Identity",
        instruction: "Apply \\( 1 - \\cos u = 2\\sin^2(u/2) \\) and \\( \\sin u = 2\\sin(u/2)\\cos(u/2) \\) to simplify the quotient.",
        options: [
          { id: 'A', text: "\\( \\frac{1}{2}\\csc^2(u/2) - \\cot(u/2) \\)", isCorrect: true, feedback: "Spot on! \\( \\frac{1}{2\\sin^2(u/2)} - \\frac{2\\sin(u/2)\\cos(u/2)}{2\\sin^2(u/2)} = \\frac{1}{2}\\csc^2(u/2) - \\cot(u/2) \\)." },
          { id: 'B', text: "\\( \\csc^2(u/2) - \\tan(u/2) \\)", isCorrect: false, feedback: "Incorrect. Notice the coefficient \\( 1/2 \\) and \\( \\cos/\\sin = \\cot \\)." },
          { id: 'C', text: "\\( \\frac{1}{2}\\sec^2(u/2) - \\tan(u/2) \\)", isCorrect: false, feedback: "Incorrect. Sine in denominator yields cosecant, not secant." },
          { id: 'D', text: "\\( 1 - 2\\cot(u/2) \\)", isCorrect: false, feedback: "Incorrect. The first term cannot be simplified to 1." }
        ],
        takeaway: "The integrand is \\( e^u \\left[ -\\cot(u/2) + \\frac{1}{2}\\csc^2(u/2) \\right] \\)."
      },
      {
        stepIndex: 3,
        title: "Step 3: Antiderivative and Constant C",
        instruction: "Identify \\( g(u) = -\\cot(u/2) \\). Integrate and find \\( C \\) using \\( f(e^{\\pi/2}) = -e^{\\pi/2} \\).",
        options: [
          { id: 'A', text: "\\( f(t) = -t\\cot\\left(\\frac{\\log_e t}{2}\\right) \\quad (C = 0) \\)", isCorrect: true, feedback: "Correct! \\( f(e^{\\pi/2}) = -e^{\\pi/2}\\cot(\\pi/4) + C = -e^{\\pi/2} + C = -e^{\\pi/2} \\implies C = 0 \\)." },
          { id: 'B', text: "\\( f(t) = t\\cot\\left(\\frac{\\log_e t}{2}\\right) - 2e^{\\pi/2} \\)", isCorrect: false, feedback: "Incorrect. The derivative of \\( \\cot \\) is negative, so the function must start with \\( -t\\cot \\)." },
          { id: 'C', text: "\\( f(t) = -t\\tan\\left(\\frac{\\log_e t}{2}\\right) \\quad (C = 0) \\)", isCorrect: false, feedback: "Incorrect. The function is cotangent, not tangent." },
          { id: 'D', text: "\\( f(t) = -t\\csc^2\\left(\\frac{\\log_e t}{2}\\right) \\)", isCorrect: false, feedback: "Incorrect. Cosecant squared is the derivative, not the function." }
        ],
        takeaway: "Antiderivative simplifies cleanly to \\( f(t) = -t\\cot\\left(\\frac{\\log_e t}{2}\\right) \\)."
      },
      {
        stepIndex: 4,
        title: "Step 4: Evaluating alpha at t = e^(pi/4)",
        instruction: "Calculate \\( f(e^{\\pi/4}) = -e^{\\pi/4}\\cot(\\pi/8) \\). Use \\( \\cot(\\pi/8) = 1 + \\sqrt{2} \\).",
        options: [
          { id: 'A', text: "\\( \\alpha = -1 - \\sqrt{2} \\)", isCorrect: true, feedback: "Bravo! \\( f(e^{\\pi/4}) = -e^{\\pi/4}(1 + \\sqrt{2}) = (-1 - \\sqrt{2})e^{\\pi/4} \\implies \\alpha = -1 - \\sqrt{2} \\)." },
          { id: 'B', text: "\\( \\alpha = 1 + \\sqrt{2} \\)", isCorrect: false, feedback: "Incorrect. Watch the leading negative sign on \\( -t\\cot(...) \\)." },
          { id: 'C', text: "\\( \\alpha = -1 + \\sqrt{2} \\)", isCorrect: false, feedback: "Incorrect. Multiplying \\( (1+\\sqrt{2}) \\) by \\( -1 \\) gives \\( -1 - \\sqrt{2} \\)." },
          { id: 'D', text: "\\( \\alpha = -1 - 2\\sqrt{2} \\)", isCorrect: false, feedback: "Incorrect. Check the half-angle formula for \\( \\cot(\\pi/8) = \\sqrt{2} + 1 \\)." }
        ],
        takeaway: "Final Answer: Option 2 (\\( -1 - \\sqrt{2} \\))."
      }
    ]
  }
];
